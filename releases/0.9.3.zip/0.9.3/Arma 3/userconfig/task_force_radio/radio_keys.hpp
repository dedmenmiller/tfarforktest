﻿class task_force_radio_settings {
	// =================================================
	// Server side only
	// =================================================
	tf_no_auto_long_range_radio = 0;
	TF_give_personal_radio_to_regular_soldier = 0;
	tf_same_sw_frequencies_for_side = 0;
	tf_same_lr_frequencies_for_side = 0;
	tf_same_dd_frequencies_for_side = 0;
	// =================================================
	// END: Server side only
	// =================================================
	// Client side
	// =================================================
	tf_default_radioVolume = 7;
	// =================================================
	// END: Client side
	// =================================================
};